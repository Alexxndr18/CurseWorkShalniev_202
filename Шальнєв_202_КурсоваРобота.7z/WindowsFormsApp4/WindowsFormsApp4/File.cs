﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    class File
    {
        public static void create(ref TextBox textBox1, ref string theWayToTheFile, ref bool editing) // Створити файл
        {
            string crtFile = Properties.Settings.Default.docNew;
            textBox1.Clear();
            theWayToTheFile = " ";
            editing = false;
            Form1.ActiveForm.Text = crtFile ;
        }

        public static void save(ref TextBox textBox1, ref string theWayToTheFile, ref bool editing) // Зберегти
        {
            FileStream folder = new FileStream(theWayToTheFile, FileMode.Create, FileAccess.Write);
            StreamWriter wrtFile = new StreamWriter(folder, Encoding.Default);
            wrtFile.Write(textBox1.Text);
            wrtFile.Close();
            editing = false;
        }
        public static void saveNewFile(ref TextBox textBox1, ref string theWayToTheFile, ref bool editing) // Зберегти як
        {
            SaveFileDialog save = new SaveFileDialog();
            save.FileName = "Новий документ";
            save.Filter = "Txt file (*.txt) |*.txt ";
            if (save.ShowDialog() == DialogResult.OK)
            {
                FileStream folder = new FileStream(save.FileName, FileMode.Create, FileAccess.Write);
                StreamWriter wrtFolder = new StreamWriter(folder, Encoding.Default);
                wrtFolder.Write(textBox1.Text);
                wrtFolder.Close();
                editing = false;
                theWayToTheFile = save.FileName;
                Form1.ActiveForm.Text = Path.GetFileName(save.FileName);
            }

        }

        public static void open(ref TextBox textBox1, ref string theWayToTheFile, ref bool editing) // Відкрити файл
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Title = "Відкрити документ";
            if (open.ShowDialog() == DialogResult.OK)
            {
                FileStream folder = new FileStream(open.FileName, FileMode.Open, FileAccess.Read);
                StreamReader filerdr = new StreamReader(folder, Encoding.Default);
                textBox1.Text = filerdr.ReadToEnd();
                filerdr.Close();
                theWayToTheFile = open.FileName;
                editing = false;
                Form1.ActiveForm.Text = open.SafeFileName ;
            }
        }

      
    }

}
