﻿using System;
using System.Windows.Forms;
 

namespace WindowsFormsApp4
{
    public partial class SearchForm : Form
    {
       
        public SearchForm()
        {
            InitializeComponent();
        }

        private void FormSearch_Load(object sender, EventArgs e)
        {
            textFind.Focus();
        }
        int length = 0;
        private void textFind_TextChanged(object sender, EventArgs e)
        {
            length = 0;
        }
        private void textReplace_TextChanged(object sender, EventArgs e)
        {
            length = 0;
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            Form1 form = this.Owner as Form1;
            if (form != null)
            {
                
                
                    Editing.searchTxt(ref form.textBox1, ref length, textFind.Text);
                
            }
        }

        private void buttonReplace_Click(object sender, EventArgs e)
        {
            Form1 form = this.Owner as Form1;
            if (form != null)
            {
                    Editing.replTxt(ref form.textBox1, textFind.Text, textReplace.Text, ref length);
            }
        }

        private void buttonReplaceAll_Click(object sender, EventArgs e)
        {
            Form1 form = this.Owner as Form1;
            if (form != null)
            {
                    Editing.repTxtAll(ref form.textBox1, textFind.Text, textReplace.Text);
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            length = 0;
        }
    }
}
   
