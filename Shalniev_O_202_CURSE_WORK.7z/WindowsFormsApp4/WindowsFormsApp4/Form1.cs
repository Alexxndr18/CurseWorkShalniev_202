﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
    
        bool editing = false;
        string theWayToTheFile = "";
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            editing = true;
            Editing.CountLinesAndWords(ref textBox1, ref lineStripStatusLabel1, ref wordStripStatusLabel2);
            Editing.Pravka(ref textBox1, ref copyPrav, ref cutPrav, ref delPrav, ref findPrav);
        }

        private void createFile_Click(object sender, EventArgs e)
        {
            if (editing == true)
            {
                DialogResult dialogueMessage = MessageBox.Show("Чи бажаете зберегти текст перед створенням нового документа?", "Створити документ", MessageBoxButtons.YesNoCancel);
                if (dialogueMessage == DialogResult.Yes)
                {
                    if (theWayToTheFile != "")
                    {
                        File.saveNewFile(ref textBox1, ref theWayToTheFile, ref editing);
                        File.create(ref textBox1, ref theWayToTheFile, ref editing);
                    }
                    else if (theWayToTheFile == "")
                    {
                        File.saveNewFile(ref textBox1, ref theWayToTheFile, ref editing);
                        File.create(ref textBox1, ref theWayToTheFile, ref editing);
                    }
                }
                else if (dialogueMessage == DialogResult.No)
                {
                    File.create(ref textBox1, ref theWayToTheFile,ref editing);
                }
            }
            else
            {
                File.create(ref textBox1, ref theWayToTheFile, ref editing);
            }
        }

        private void openFile_Click(object sender, EventArgs e)
        {
            if (editing == true)
            {
                DialogResult dialogueMessage = MessageBox.Show("Чи бажаєте зберегти цей документ?", "Відкрити документ", MessageBoxButtons.YesNo);
                if (dialogueMessage == DialogResult.Yes)
                {
                    if (theWayToTheFile != "")
                    {
                        File.save(ref textBox1, ref theWayToTheFile, ref editing);
                        File.open(ref textBox1, ref theWayToTheFile, ref editing);
                    }
                    else if (theWayToTheFile == "")
                    {
                        File.save(ref textBox1, ref theWayToTheFile, ref editing);
                        File.open(ref textBox1, ref theWayToTheFile, ref editing);
                    }
                }
                else if (dialogueMessage == DialogResult.No)
                {
                    File.open(ref textBox1, ref theWayToTheFile, ref editing);
                }
                else
                {
                    return;
                }
            }
            else
            {
                File.open(ref textBox1, ref theWayToTheFile, ref editing);
            }
        }

        private void saveFile_Click(object sender, EventArgs e)
        {
            if (theWayToTheFile != "")
            {
                File.save(ref textBox1, ref theWayToTheFile, ref editing);
            }
            else
            {
                File.saveNewFile(ref textBox1,  ref theWayToTheFile, ref editing);
            }
        }

        private void saveAs_Click(object sender, EventArgs e)
        {
            File.saveNewFile(ref textBox1, ref theWayToTheFile, ref editing);
        }

        private void closeFile_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void cancelPrav_Click(object sender, EventArgs e)
        {
            textBox1.Undo();
        }

        private void cutPrav_Click(object sender, EventArgs e)
        {
            if (textBox1.SelectionLength > 0)
            {
                textBox1.Cut();
            }
        }

        private void copyPrav_Click(object sender, EventArgs e)
        {
            if (textBox1.SelectionLength > 0)
            {
                textBox1.Copy();
            }
        }

        private void pastePrav_Click(object sender, EventArgs e)
        {
            textBox1.Paste();
        }

        private void delPrav_Click(object sender, EventArgs e)
        {
            if (textBox1.SelectionLength > 0)
            {
                textBox1.SelectedText = "";
            }
        }

        private void findPrav_Click(object sender, EventArgs e)
        {
            SearchForm find = new SearchForm();
            find.Owner = this;
            find.Show();
        }

        private void selectTextPrav_Click(object sender, EventArgs e)
        {
            textBox1.SelectAll();
        }

        private void fontPrav_Click(object sender, EventArgs e)
        {
            fontDialog1.Font = textBox1.Font;
            DialogResult = fontDialog1.ShowDialog();
            if (DialogResult == DialogResult.OK)
            {
                textBox1.Font = fontDialog1.Font;
            }
        }
        
        private void ResetAllControlsBackColor(Control childControl)
        {
            throw new NotImplementedException();
        }

        private void aboutProg_Click(object sender, EventArgs e)
        {
            AboutForm about = new AboutForm();
            about.Show();
           
        }

      
    }
}
