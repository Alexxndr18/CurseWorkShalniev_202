﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

    
namespace WindowsFormsApp4
{
    public static class Editing
    {
       
        public static int searchTxt(ref TextBox contentCase, ref int len, string findRequiredTxt)
        {
            
                if (contentCase.Text.Contains(findRequiredTxt))
                {
                
                    string mainText = contentCase.Text;
                    string followingText = mainText.Remove(0, len);
                  
                    int loc = followingText.IndexOf(findRequiredTxt);
                    
                    if (loc != -1)
                    {
                        contentCase.Select(loc + len, findRequiredTxt.Length);
                        contentCase.ScrollToCaret();
                        contentCase.Focus();
                        len += findRequiredTxt.Length + loc;
                    }
                 
                    else if ( len != 0 && loc == -1)
                    {
                        len = 0;
                        return searchTxt(ref contentCase, ref len, findRequiredTxt);
                    }
                }
                else
                {
                    len = 0;
                    MessageBox.Show("Не вдалось знайти необхідне слово.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            return 0;
        }

        public static int replTxt(ref TextBox contentCase, string findRequiredTxt, string repRequiredTxt, ref int len)
        {
            if (contentCase.Text.Contains(findRequiredTxt))
                {
                    if (contentCase.SelectedText == "" || contentCase.SelectedText != findRequiredTxt)
                    {
                        string mainTxt = contentCase.Text;
                        string followingTxt = mainTxt.Remove(0, len);
                        int loc = followingTxt.IndexOf(findRequiredTxt);
                        if (loc != -1)
                        {
                            contentCase.Select(loc + len, findRequiredTxt.Length);
                            contentCase.ScrollToCaret();
                            contentCase.Focus();
                            len += findRequiredTxt.Length + loc;
                        }
                        else if (len != 0 && loc == -1)
                        {
                            len = 0;
                            return replTxt(ref contentCase, findRequiredTxt, repRequiredTxt, ref len);
                        }
                    }
                    else if (contentCase.SelectedText == findRequiredTxt)
                    {
                        contentCase.SelectedText = repRequiredTxt;
                    }
                }
                else
                {
                    len = 0;
                    MessageBox.Show("За вашим запитом нічого не знайшлося.", "Повідомлення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            return 0;
        }

        public static int repTxtAll(ref TextBox contentCase, string findRequiredTxt, string repRequiredTxt)
        {
                string mainTxt = contentCase.Text;
                string yourPut = findRequiredTxt;
            if (contentCase.Text.Contains(yourPut))
                    {
                        int locBegin = mainTxt.IndexOf(yourPut);
                        contentCase.Select(locBegin, yourPut.Length);
                        contentCase.SelectedText = repRequiredTxt;
                        return repTxtAll(ref contentCase, findRequiredTxt, repRequiredTxt);
                    }
                
                else
                {
                    MessageBox.Show("Операція була виконана успішно", "Повідомлення", MessageBoxButtons.OK);
                }
            return 0;
        }

        public static void Pravka(ref TextBox contentCase, ref ToolStripMenuItem copyPrav, ref ToolStripMenuItem cutPrav, ref ToolStripMenuItem delPrav, ref ToolStripMenuItem findPrav)
        {
            if (contentCase.Text.Length < 1)
            {
                copyPrav.Enabled = false; cutPrav.Enabled = false; delPrav.Enabled = false; findPrav.Enabled = false;
            }
            else
            {
                copyPrav.Enabled = true; cutPrav.Enabled = true; delPrav.Enabled = true; findPrav.Enabled = true;
            }
        }

        public static void CountLinesAndWords(ref TextBox contentCase, ref ToolStripStatusLabel lineStripStatusLabel1, ref ToolStripStatusLabel wordStripStatusLabel2)
        {
            string text = contentCase.Text;   
            lineStripStatusLabel1.Text = contentCase.Lines.Count().ToString();       
            wordStripStatusLabel2.Text = text.Split(new Char[] {}, StringSplitOptions.RemoveEmptyEntries).Length.ToString();
        }
    }
}

