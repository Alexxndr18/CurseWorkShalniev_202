﻿
namespace WindowsFormsApp4
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.create = new System.Windows.Forms.ToolStripMenuItem();
            this.open = new System.Windows.Forms.ToolStripMenuItem();
            this.save = new System.Windows.Forms.ToolStripMenuItem();
            this.saveNewFile = new System.Windows.Forms.ToolStripMenuItem();
            this.closeFile = new System.Windows.Forms.ToolStripMenuItem();
            this.правкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelPrav = new System.Windows.Forms.ToolStripMenuItem();
            this.cutPrav = new System.Windows.Forms.ToolStripMenuItem();
            this.copyPrav = new System.Windows.Forms.ToolStripMenuItem();
            this.pastePrav = new System.Windows.Forms.ToolStripMenuItem();
            this.delPrav = new System.Windows.Forms.ToolStripMenuItem();
            this.findPrav = new System.Windows.Forms.ToolStripMenuItem();
            this.selectTextPrav = new System.Windows.Forms.ToolStripMenuItem();
            this.форматToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontPrav = new System.Windows.Forms.ToolStripMenuItem();
            this.colorPrav = new System.Windows.Forms.ToolStripMenuItem();
            this.довідкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutProg = new System.Windows.Forms.ToolStripMenuItem();
            this.lineStatusStrip = new System.Windows.Forms.StatusStrip();
            this.lineCountStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.wordCountStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.lineStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.wordStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.menuStrip1.SuspendLayout();
            this.lineStatusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.правкаToolStripMenuItem,
            this.форматToolStripMenuItem,
            this.довідкаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.create,
            this.open,
            this.save,
            this.saveNewFile,
            this.closeFile});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // create
            // 
            this.create.Name = "create";
            this.create.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.create.Size = new System.Drawing.Size(211, 22);
            this.create.Text = "Створити";
            this.create.Click += new System.EventHandler(this.createFile_Click);
            // 
            // open
            // 
            this.open.Name = "open";
            this.open.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.open.Size = new System.Drawing.Size(211, 22);
            this.open.Text = "Відкрити";
            this.open.Click += new System.EventHandler(this.openFile_Click);
            // 
            // save
            // 
            this.save.Name = "save";
            this.save.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.save.Size = new System.Drawing.Size(211, 22);
            this.save.Text = "Зберегти";
            this.save.Click += new System.EventHandler(this.saveFile_Click);
            // 
            // saveNewFile
            // 
            this.saveNewFile.Name = "saveNewFile";
            this.saveNewFile.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Alt) 
            | System.Windows.Forms.Keys.S)));
            this.saveNewFile.Size = new System.Drawing.Size(211, 22);
            this.saveNewFile.Text = "Зберегти як...";
            this.saveNewFile.Click += new System.EventHandler(this.saveAs_Click);
            // 
            // closeFile
            // 
            this.closeFile.Name = "closeFile";
            this.closeFile.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.closeFile.Size = new System.Drawing.Size(211, 22);
            this.closeFile.Text = "Вихід";
            this.closeFile.Click += new System.EventHandler(this.closeFile_Click);
            // 
            // правкаToolStripMenuItem
            // 
            this.правкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cancelPrav,
            this.cutPrav,
            this.copyPrav,
            this.pastePrav,
            this.delPrav,
            this.findPrav,
            this.selectTextPrav});
            this.правкаToolStripMenuItem.Name = "правкаToolStripMenuItem";
            this.правкаToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.правкаToolStripMenuItem.Text = "Правка";
            // 
            // cancelPrav
            // 
            this.cancelPrav.Name = "cancelPrav";
            this.cancelPrav.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.cancelPrav.Size = new System.Drawing.Size(219, 22);
            this.cancelPrav.Text = "Скасувати";
            this.cancelPrav.Click += new System.EventHandler(this.cancelPrav_Click);
            // 
            // cutPrav
            // 
            this.cutPrav.Name = "cutPrav";
            this.cutPrav.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.cutPrav.Size = new System.Drawing.Size(219, 22);
            this.cutPrav.Text = "Вирізати";
            this.cutPrav.Click += new System.EventHandler(this.cutPrav_Click);
            // 
            // copyPrav
            // 
            this.copyPrav.Name = "copyPrav";
            this.copyPrav.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copyPrav.Size = new System.Drawing.Size(219, 22);
            this.copyPrav.Text = "Скопіювати";
            this.copyPrav.Click += new System.EventHandler(this.copyPrav_Click);
            // 
            // pastePrav
            // 
            this.pastePrav.Name = "pastePrav";
            this.pastePrav.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.pastePrav.Size = new System.Drawing.Size(219, 22);
            this.pastePrav.Text = "Вставити";
            this.pastePrav.Click += new System.EventHandler(this.pastePrav_Click);
            // 
            // delPrav
            // 
            this.delPrav.Name = "delPrav";
            this.delPrav.ShortcutKeys = System.Windows.Forms.Keys.Delete;
            this.delPrav.Size = new System.Drawing.Size(219, 22);
            this.delPrav.Text = "Видалити";
            this.delPrav.Click += new System.EventHandler(this.delPrav_Click);
            // 
            // findPrav
            // 
            this.findPrav.Name = "findPrav";
            this.findPrav.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.findPrav.Size = new System.Drawing.Size(219, 22);
            this.findPrav.Text = "Знайти та замінити";
            this.findPrav.Click += new System.EventHandler(this.findPrav_Click);
            // 
            // selectTextPrav
            // 
            this.selectTextPrav.Name = "selectTextPrav";
            this.selectTextPrav.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.selectTextPrav.Size = new System.Drawing.Size(219, 22);
            this.selectTextPrav.Text = "Виділити текст";
            this.selectTextPrav.Click += new System.EventHandler(this.selectTextPrav_Click);
            // 
            // форматToolStripMenuItem
            // 
            this.форматToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fontPrav,
            this.colorPrav});
            this.форматToolStripMenuItem.Name = "форматToolStripMenuItem";
            this.форматToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.форматToolStripMenuItem.Text = "Формат";
            // 
            // fontPrav
            // 
            this.fontPrav.Name = "fontPrav";
            this.fontPrav.Size = new System.Drawing.Size(180, 22);
            this.fontPrav.Text = "Шрифт";
            this.fontPrav.Click += new System.EventHandler(this.fontPrav_Click);
            // 
            // colorPrav
            // 
            this.colorPrav.Name = "colorPrav";
            this.colorPrav.Size = new System.Drawing.Size(180, 22);
            this.colorPrav.Text = "Колір";
            this.colorPrav.Click += new System.EventHandler(this.colorPrav_Click);
            // 
            // довідкаToolStripMenuItem
            // 
            this.довідкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutProg});
            this.довідкаToolStripMenuItem.Name = "довідкаToolStripMenuItem";
            this.довідкаToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.довідкаToolStripMenuItem.Text = "Довідка";
            // 
            // aboutProg
            // 
            this.aboutProg.Name = "aboutProg";
            this.aboutProg.Size = new System.Drawing.Size(162, 22);
            this.aboutProg.Text = "Про \"Нотатник\"";
            this.aboutProg.Click += new System.EventHandler(this.aboutProg_Click);
            // 
            // lineStatusStrip
            // 
            this.lineStatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lineCountStatus,
            this.wordCountStatus,
            this.lineStripStatusLabel1,
            this.wordStripStatusLabel2});
            this.lineStatusStrip.Location = new System.Drawing.Point(0, 428);
            this.lineStatusStrip.Name = "lineStatusStrip";
            this.lineStatusStrip.Size = new System.Drawing.Size(800, 22);
            this.lineStatusStrip.TabIndex = 1;
            this.lineStatusStrip.Text = "statusStrip1";
            // 
            // lineCountStatus
            // 
            this.lineCountStatus.Name = "lineCountStatus";
            this.lineCountStatus.Size = new System.Drawing.Size(0, 17);
            // 
            // wordCountStatus
            // 
            this.wordCountStatus.Name = "wordCountStatus";
            this.wordCountStatus.Size = new System.Drawing.Size(0, 17);
            // 
            // lineStripStatusLabel1
            // 
            this.lineStripStatusLabel1.Name = "lineStripStatusLabel1";
            this.lineStripStatusLabel1.Size = new System.Drawing.Size(10, 17);
            this.lineStripStatusLabel1.Text = " ";
            // 
            // wordStripStatusLabel2
            // 
            this.wordStripStatusLabel2.Name = "wordStripStatusLabel2";
            this.wordStripStatusLabel2.Size = new System.Drawing.Size(10, 17);
            this.wordStripStatusLabel2.Text = " ";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.AliceBlue;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Location = new System.Drawing.Point(0, 24);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(800, 404);
            this.textBox1.TabIndex = 2;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lineStatusStrip);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Нотатник";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.lineStatusStrip.ResumeLayout(false);
            this.lineStatusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem create;
        private System.Windows.Forms.ToolStripMenuItem open;
        private System.Windows.Forms.ToolStripMenuItem save;
        private System.Windows.Forms.ToolStripMenuItem saveNewFile;
        private System.Windows.Forms.ToolStripMenuItem closeFile;
        private System.Windows.Forms.ToolStripMenuItem правкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cancelPrav;
        private System.Windows.Forms.ToolStripMenuItem cutPrav;
        private System.Windows.Forms.ToolStripMenuItem copyPrav;
        private System.Windows.Forms.ToolStripMenuItem pastePrav;
        private System.Windows.Forms.ToolStripMenuItem delPrav;
        private System.Windows.Forms.ToolStripMenuItem findPrav;
        private System.Windows.Forms.ToolStripMenuItem selectTextPrav;
        private System.Windows.Forms.ToolStripMenuItem форматToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fontPrav;
        private System.Windows.Forms.ToolStripMenuItem довідкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutProg;
        private System.Windows.Forms.StatusStrip lineStatusStrip;
        public System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.FontDialog fontDialog1;
        protected System.Windows.Forms.ToolStripStatusLabel wordCountStatus;
        protected System.Windows.Forms.ToolStripStatusLabel lineCountStatus;
        private System.Windows.Forms.ToolStripStatusLabel lineStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel wordStripStatusLabel2;
        private System.Windows.Forms.ToolStripMenuItem colorPrav;
    }
}

